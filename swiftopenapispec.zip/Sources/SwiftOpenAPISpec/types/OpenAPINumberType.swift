///*
// * Copyright 2025 CgSe Computergrafik und Softwareentwicklung GmbH
// *
// * Licensed under the Apache License, Version 2.0 (the "License");
// * you may not use this file except in compliance with the License.
// * You may obtain a copy of the License at
// *
// *     http://www.apache.org/licenses/LICENSE-2.0
// *
// * Unless required by applicable law or agreed to in writing, software
// * distributed under the License is distributed on an "AS IS" BASIS,
// * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// * See the License for the specific language governing permissions and
// * limitations under the License.
// */
//
///*
// * Copyright 2025 
// *
// * Licensed under the Apache License, Version 2.0 (the "License");
// * you may not use this file except in compliance with the License.
// * You may obtain a copy of the License at
// *
// *     http://www.apache.org/licenses/LICENSE-2.0
// *
// * Unless required by applicable law or agreed to in writing, software
// * distributed under the License is distributed on an "AS IS" BASIS,
// * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// * See the License for the specific language governing permissions and
// * limitations under the License.
// */
//
////
////  OpenAPIIntegerType.swift
////  SwiftOpenAPISpec
////
////  Created by Patric Dubois on 07.12.25.
////
//
//
//public struct OpenAPINumberType : OpenAPISchemaType  {
//    public var discriminator: OpenAPIDiscriminator?
//    
//    public var nullable: Bool?
//    
//    public var readOnly: Bool?
//    
//    public var writeOnly: Bool?
//    
//    public var xml: OpenAPIXMLObject?
//    
//    public var externalDocs: OpenAPIExternalDocumentation?
//    
//    public var example: OpenAPIExample?
//    
//    public var deprecated: Bool?
//    
//    public var extensions: OpenAPIExtension?
//    
//    public func element(for segmentName: String) throws -> Any? {
//        switch segmentName {
//        case Self.FORMAT_KEY : return format
//        case Self.TYPE_KEY : return type
//        case Self.DEFAULT_KEY :return defaultValue
//        case Self.MULTIPLEOF_KEY :return multipleOf
//        case Self.MINIMUM_KEY: return minimum
//        case Self.MAXIMUM_KEY :return maximum
//        case Self.EXCLUSIVEMINIMUM_KEY : return exclusiveMinimum
//        case Self.EXCLUSIVEMAXIMUM_KEY : return exclusiveMaximum
//        default:
//                    throw OpenAPISpecification.Errors.unsupportedSegment("OpenAPIDoubleType", segmentName)
//        }
//    }
//    
//  
//    
//    
//    public static let FORMAT_KEY : String = "format"
//    public static let TYPE_KEY = "type"
//    public static let DEFAULT_KEY = "default"
//    public static let MULTIPLEOF_KEY = "multipleOf"
//    public static let MINIMUM_KEY = "minimum"
//    public static let MAXIMUM_KEY = "maximum"
//    public static let EXCLUSIVEMINIMUM_KEY = "exclusiveMinimum"
//    public static let EXCLUSIVEMAXIMUM_KEY = "exclusiveMaximum"
//   
//    public init(load map: [String : Any]) throws {
//        self.type = map[Self.TYPE_KEY] as? String
//        
//        self.defaultValue = map[Self.DEFAULT_KEY] as? Double
//        self.multipleOf =  map[Self.MULTIPLEOF_KEY] as? Double
//        self.maximum =  map[Self.MAXIMUM_KEY] as? Double
//        self.exclusiveMaximum =  map[Self.EXCLUSIVEMAXIMUM_KEY] as? Double
//        self.minimum =  map[Self.MINIMUM_KEY] as? Double
//        self.exclusiveMinimum =  map[Self.EXCLUSIVEMINIMUM_KEY] as? Double
//    }
//    public static func initialize(_ map: StringDictionary) throws ->  InitializationResult<Self> {
//           let element = try Self(load: map)
//           return InitializationResult(value: element, diagnostics: [])
//       }
//
//    public var format : String?
//    public var multipleOf :Double?
//    public var defaultValue : Double?
//    public var maximum : Double?
//    public var exclusiveMaximum :Double?
//    public var minimum : Double?
//    public var exclusiveMinimum :Double?
//    public var type : String?
//    public var ref: OpenAPISchemaReference? { nil}
//    
//}
